<div class="body_padded">
	<h1>Help - XSS</h1>
	
	<div id="code">
	<table width='100%' bgcolor='white' style="border:2px #C0C0C0 solid">
	<tr>
	<td><div id="code">

		<p> 看上去 htmlspecialchars() 函数没有起到作用 , 试一下任何攻击向量比如 &ltimg src=x onerror=alert()&gt 这是为什么呢 ? 去wooyun.org查看原始的漏洞报告！ </p>
		
	</div></td>
	</tr>
	</table>
	
	</div>
	
	<br />
	
	<p>Reference: http://www.wooyun.org/bugs/wooyun-2014-051536</p>
	<p>Reference: http://drops.wooyun.org/tips/956</p>

</div>
		