<?php	

/*

I know you are lazy.
So I decompiled the swf file for u.

我知道你很懒
所以我帮你把swf反编译好了

*/

/*

var func:String=root.loaderInfo.parameters.func;
ExternalInterface.call(func,"1");

*/

?>
