<div class="body_padded">
	<h1>Help - XSS</h1>
	
	<div id="code">
	<table width='100%' bgcolor='white' style="border:2px #C0C0C0 solid">
	<tr>
	<td><div id="code">

		<p> 试一试 123%0aalert(123)// (BTW. 你知道怎么输入的 %0a 对吧?) , 去wooyun.org查看原始的漏洞报告！ </p>
		
	</div></td>
	</tr>
	</table>
	
	</div>
	
	<br />
	
	<p>Reference: http://www.wooyun.org/bugs/wooyun-2010-016003</p>

</div>
		