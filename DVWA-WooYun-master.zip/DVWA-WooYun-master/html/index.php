<?php
$con = mysql_connect("localhost","root","toor");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

$sql = "CREATE DATABASE IF NOT EXISTS dvwa";
mysql_query($sql,$con);
mysql_close($con);
header("location: /web");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" lang="zh-CN">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="author" content="Ambulong" />
  <meta http-equiv="refresh" content="3">
  <title> LOADING VULNSPY ENV.</title>
</head>
<style>
html,body{
	width: 100%;
	height: 100%;
	color: #444;
}
</style>
<body>
  <div style="height: 70%;display:flex;justify-content:center;align-items:center;">
  	<h1 style="width:100%;font-weight:normal;font-size:400%;text-align:center;">Loading . . . </h1>
  </div>
</body>
</html>
