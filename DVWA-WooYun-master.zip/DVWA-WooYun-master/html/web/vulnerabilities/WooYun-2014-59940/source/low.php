<?php	

This file is useless , press the button and see the test.html...

?>
