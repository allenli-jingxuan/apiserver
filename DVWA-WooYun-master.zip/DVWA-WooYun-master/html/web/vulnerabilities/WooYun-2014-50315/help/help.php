<div class="body_padded">
	<h1>Help - XSS</h1>
	
	<div id="code">
	<table width='100%' bgcolor='white' style="border:2px #C0C0C0 solid">
	<tr>
	<td><div id="code">

		<p>  去wooyun.org查看原始的漏洞报告！ </p>
		
	</div></td>
	</tr>
	</table>
	
	</div>
	
	<br />
	
	<p>Reference: http://www.wooyun.org/bugs/wooyun-2010-050315</p>
	<p>Reference: http://drops.wooyun.org/papers/917</p>

</div>
		