<div class="body_padded">
	<h1>Help - XSS</h1>
	
	<div id="code">
	<table width='100%' bgcolor='white' style="border:2px #C0C0C0 solid">
	<tr>
	<td><div id="code">

		<p> 试一试 aaaa\  和   =1;alert(1);function/**/from(){}//  (第一个是 $ss , 第二个是 $from) , 去wooyun.org查看原始的漏洞报告！ </p>
		
	</div></td>
	</tr>
	</table>
	
	</div>
	
	<br />
	
	<p>Reference: http://www.wooyun.org/bugs/wooyun-2010-015979</p>

</div>
		