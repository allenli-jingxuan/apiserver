<div class="body_padded">
	<h1>Help - SQL Injection</h1>
	
	<div id="code">
	<table width='100%' bgcolor='white' style="border:2px #C0C0C0 solid">
	<tr>
	<td><div id="code">

		<p> 看上去有过滤函数在起作用 , 试一试 1' anand d '1'='1 , 去wooyun.org查看原始的漏洞报告！ </p>
		
		<p> The 'id' variable within this PHP script is vulnerable to SQL injection.</p>
		
		<p> There are 5 users in the database, with id's from 1 to 5. Your mission... to steal passwords!</p>
		
		<p> If you have received a Magicquotes error, turn them off in php.ini.</p>
		
	</div></td>
	</tr>
	</table>
	
	</div>
	
	<br />
	
	<p>Reference: http://www.wooyun.org/bugs/wooyun-2014-053384</p>

</div>
		